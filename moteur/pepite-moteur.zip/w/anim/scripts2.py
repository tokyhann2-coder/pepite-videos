# scene: dict(kind, voice, lines (on-screen, '*kw*' = highlighted), emoji, extra)
V = {
"a-bebe-3-jeux": dict(tint="#FBE0DA", page="kit-eveil-0-2-ans-3.jpg", scenes=[
 dict(kind="hook", voice="Votre bébé s'ennuie ? Voici trois jeux d'éveil avec ce que vous avez déjà à la maison.", lines="Bébé s'ennuie ?\n*3 jeux d'éveil*\nsans rien acheter", emoji="👶"),
 dict(kind="step", n="1", voice="Un : dessinez de gros cercles noirs sur une feuille blanche. Les forts contrastes attirent son regard.", lines="Gros cercles *noirs*\nsur feuille blanche", emoji="⚫"),
 dict(kind="step", n="2", voice="Deux : un panier avec cinq objets de la cuisine, assez grands pour ne pas être avalés. Toujours sous surveillance.", lines="Un panier de *5 objets*\ntoujours surveillé", emoji="🧺"),
 dict(kind="step", n="3", voice="Trois : chantez-lui une chanson en le regardant dans les yeux. Il adore votre voix.", lines="Chantez en le\nregardant *dans les yeux*", emoji="🎵"),
 dict(kind="hook", voice="Cinq minutes suffisent. Enregistrez cette vidéo pour la retrouver.", lines="*5 minutes* suffisent.\nEnregistrez 📌", emoji="💛"),
 dict(kind="cta", voice="Notre kit d'éveil propose quatre semaines d'activités à imprimer. Le quiz gratuit est en lien dans la bio.", lines="Kit éveil 0-2 ans\n*Quiz gratuit*", emoji="")]),
"b-quiz-5-6": dict(tint="#DDF1E7", page="kit-lecture-calcul-5-6-ans-03.jpg", scenes=[
 dict(kind="hook", voice="Mini quiz pour parents. Votre enfant de cinq ans sait-il répondre à ces trois questions ?", lines="*Mini quiz* parents\nVotre enfant de 5 ans\nsait répondre ?", emoji="🧠"),
 dict(kind="quizq", n="1", voice="Question un : combien y a-t-il de syllabes dans le mot banane ?", lines="Combien de syllabes\ndans *banane* ?", emoji="🍌", pause=3.6),
 dict(kind="quiza", n="1", voice="Réponse : trois ! Ba, na, ne.", lines="*3* syllabes\nBA · NA · NE", emoji="✅"),
 dict(kind="quizq", n="2", voice="Question deux : quel nombre vient juste après dix-neuf ?", lines="Quel nombre vient\naprès *19* ?", emoji="🔢", pause=3.6),
 dict(kind="quiza", n="2", voice="Réponse : vingt !", lines="*20* !", emoji="✅"),
 dict(kind="quizq", n="3", voice="Question trois : quelle est la première lettre du mot soleil ?", lines="Première lettre\ndu mot *soleil* ?", emoji="☀️", pause=3.6),
 dict(kind="quiza", n="3", voice="Réponse : la lettre S !", lines="La lettre *S*", emoji="✅"),
 dict(kind="cta", voice="Notre kit de quatre semaines travaille ça en s'amusant. Le quiz gratuit est en lien dans la bio.", lines="Kit 5-6 ans\n*Quiz gratuit*", emoji="")]),
"c-phrases-3-4": dict(tint="#FDEFC9", page="kit-decouverte-3-4-ans-03.jpg", scenes=[
 dict(kind="hook", voice="Arrêtez de dire dépêche-toi. Voici trois phrases à dire à la place.", lines="Arrêtez de dire\n*« Dépêche-toi »*\nDites plutôt…", emoji="🛑"),
 dict(kind="step", n="1", voice="Un : tu veux commencer par quoi ? Offrir un choix évite beaucoup de bras de fer.", lines="« Tu veux commencer\npar *quoi* ? »", emoji="🤔"),
 dict(kind="step", n="2", voice="Deux : on le fait ensemble cinq minutes. Un début à deux est plus facile.", lines="« On le fait\n*ensemble* 5 minutes »", emoji="🤝"),
 dict(kind="step", n="3", voice="Trois : bravo, tu as essayé. On félicite l'effort, pas seulement le résultat.", lines="« Bravo, tu\n*as essayé* ! »", emoji="🌟"),
 dict(kind="hook", voice="Petit à petit, la confiance s'installe. Partagez à un parent qui en a besoin.", lines="La confiance vient\n*petit à petit*\nPartagez 💌", emoji="🌱"),
 dict(kind="cta", voice="Notre kit de trois à quatre ans propose une activité par jour. Le quiz gratuit est en lien dans la bio.", lines="Kit 3-4 ans\n*Quiz gratuit*", emoji="")]),
}
