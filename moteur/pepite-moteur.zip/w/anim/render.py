import sys,os,json,subprocess,asyncio,numpy as np,soundfile as sf
sys.path.insert(0,'/home/claude/w/anim'); from scripts2 import V
from kokoro_onnx import Kokoro
from playwright.async_api import async_playwright
OUT='/home/claude/w/anim/out'; os.makedirs(OUT,exist_ok=True)
SR=24000; FPS=30
k=Kokoro('/home/claude/w/tts/kokoro.onnx','/home/claude/w/tts/voices.bin')
def tone(f0,f1,dur,vol,kind='pop'):
    n=int(SR*dur);t=np.arange(n)/SR;f=np.linspace(f0,f1,n);ph=2*np.pi*np.cumsum(f)/SR
    return (np.sin(ph)*np.exp(-t*(60/dur/10+8))*vol).astype(np.float32)
def ding(vol=.14):
    n=int(SR*.6);t=np.arange(n)/SR
    return ((np.sin(2*np.pi*880*t)+.6*np.sin(2*np.pi*1320*t))*np.exp(-t*7)*vol).astype(np.float32)
def mix(buf,snd,at):
    i=int(at*SR);buf[i:i+len(snd)]+=snd[:max(0,len(buf)-i)]
async def main(name):
    v=V[name];scenes=[];audio=[];t=0.0
    for sc in v['scenes']:
        s,_=k.create(sc['voice'],voice='ff_siwis',speed=0.97,lang='fr-fr')
        vd=len(s)/SR;pause=sc.get('pause',0.0);dur=vd+pause+0.45
        buf=np.zeros(int(dur*SR),dtype=np.float32);buf[:len(s)]+=s*0.95
        mix(buf,tone(350,900,.12,.18),0.02)
        if sc['kind']=='quiza': mix(buf,ding(),0.25)
        if sc['kind']=='quizq':
            for j in range(3): mix(buf,tone(1000,1000,.07,.12),vd+j*1.2+0.05)
        audio.append(buf);scenes.append(dict(sc,start=t,dur=dur,vdur=vd));t+=dur
    total=t;spec=dict(tint=v['tint'],page=v['page'],scenes=scenes,total=total)
    wav=np.concatenate(audio);wav=np.clip(wav,-1,1);sf.write(f'{OUT}/{name}.wav',wav,SR)
    nfr=int(total*FPS)
    ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','image2pipe','-framerate',str(FPS),'-c:v','mjpeg','-i','-','-i',f'{OUT}/{name}.wav',
      '-c:v','libx264','-crf','20','-preset','veryfast','-pix_fmt','yuv420p','-r',str(FPS),'-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',f'{OUT}/tmp-{name}.mp4'],stdin=subprocess.PIPE)
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--allow-file-access-from-files']);pg=await b.new_page(viewport={'width':1080,'height':1920})
        await pg.goto('file:///home/claude/w/anim/anim.html');await pg.wait_for_timeout(500)
        await pg.evaluate('s=>build(s)',spec);await pg.wait_for_timeout(300)
        for i in range(nfr):
            await pg.evaluate('t=>setTime(t)',i/FPS)
            ff.stdin.write(await pg.screenshot(type='jpeg',quality=82))
            if i==int(nfr*0.12) or i==int(nfr*0.5): await pg.screenshot(path=f'{OUT}/{name}-f{i}.png')
        await b.close()
    ff.stdin.close();ff.wait();os.replace(f'{OUT}/tmp-{name}.mp4',f'{OUT}/pepite-{name}.mp4');print(name,round(total,1),'s',nfr,'frames')
asyncio.run(main(sys.argv[1]))
